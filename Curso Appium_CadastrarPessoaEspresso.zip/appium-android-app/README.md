# Testando aplicações Android com Espresso e UIAutomator
Para abrir o projeto:

```
git clone https://github.com/clarabez/appium-android-app.git
```

Para abrir o projeto no Android Studio:
file > Open > build.gradle

## Introdução

## Espresso

Framework de automação de UI para aplicações Android a partir de um projeto de desenvolvimento nativo para Android.

[Referência](https://developer.android.com/training/testing/espresso)

## UIAutomator

[Referência](https://developer.android.com/training/testing/ui-automator?hl=pt-br)
